
import React, { useState, useMemo } from 'react';
import { TimeEntry, Project, Worker, WorkType } from '../types';
import { ChevronLeft, ChevronRight, X, Clock, Plus, Trash2, HardHat } from 'lucide-react';
import { WORK_TYPES } from '../constants';

interface Props {
  entries: TimeEntry[];
  projects: Project[];
  workers: Worker[];
  onAddEntry: (entry: Omit<TimeEntry, 'id'>) => void;
  onUpdateEntry: (id: string, updates: Partial<TimeEntry>) => void;
  onDeleteEntry: (id: string) => void;
}

const MONTHS = [
  'januari', 'februari', 'mars', 'april', 'maj', 'juni',
  'juli', 'augusti', 'september', 'oktober', 'november', 'december'
];

const formatDate = (date: Date) => {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

const ReportedSummary: React.FC<Props> = ({ 
  entries, projects, workers, onAddEntry, onUpdateEntry, onDeleteEntry 
}) => {
  const [currentDate, setCurrentDate] = useState(new Date()); 
  const [filterYear, setFilterYear] = useState(new Date().getFullYear().toString());
  const [filterMonth, setFilterMonth] = useState(MONTHS[new Date().getMonth()]);
  const [filterWeek, setFilterWeek] = useState('');
  
  // State for the time reporting modal
  const [selectedDay, setSelectedDay] = useState<Date | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Modal form state
  const [formProjectId, setFormProjectId] = useState(projects[0]?.id || '');
  const [formWorkerName, setFormWorkerName] = useState(workers[0]?.name || '');
  const [formHours, setFormHours] = useState('8');
  const [formWorkType, setFormWorkType] = useState<WorkType>(WorkType.NORMAL);
  const [formDescription, setFormDescription] = useState('');

  const daysInMonth = useMemo(() => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const date = new Date(year, month, 1);
    const days = [];
    
    let startDay = date.getDay();
    startDay = startDay === 0 ? 6 : startDay - 1;

    for (let i = 0; i < startDay; i++) {
      days.push(null);
    }

    const lastDay = new Date(year, month + 1, 0).getDate();
    for (let i = 1; i <= lastDay; i++) {
      days.push(new Date(year, month, i));
    }

    return days;
  }, [currentDate]);

  const getDayEntries = (date: Date) => {
    const dateStr = formatDate(date);
    return entries.filter(e => e.date === dateStr);
  };

  const getDayTotal = (date: Date) => {
    return getDayEntries(date).reduce((sum, e) => sum + e.hours, 0);
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const next = new Date(prev);
      next.setMonth(prev.getMonth() + (direction === 'next' ? 1 : -1));
      return next;
    });
  };

  const handleDayClick = (day: Date) => {
    setSelectedDay(day);
    setIsModalOpen(true);
    // Reset form for potential new entry
    setFormProjectId(projects[0]?.id || '');
    setFormWorkerName(workers[0]?.name || '');
    setFormHours('8');
    setFormWorkType(WorkType.NORMAL);
    setFormDescription('');
  };

  const handleModalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDay) return;
    
    onAddEntry({
      date: formatDate(selectedDay),
      projectId: formProjectId,
      workerName: formWorkerName,
      hours: parseFloat(formHours),
      workType: formWorkType,
      description: formDescription
    });
    
    setFormDescription('');
  };

  const inputClasses = "w-full px-4 py-2 border border-slate-200 rounded focus:ring-2 focus:ring-[#00b4e5] outline-none bg-[#f3f6f9] text-slate-900 appearance-none font-medium";
  const labelClasses = "block text-sm font-bold text-slate-800 mb-1.5";

  const selectedDayEntries = selectedDay ? getDayEntries(selectedDay) : [];

  return (
    <div className="space-y-4 max-w-4xl mx-auto relative">
      {/* Calendar Card */}
      <div className="bg-white rounded shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-4 flex items-center justify-between">
          <button onClick={() => navigateMonth('prev')} className="p-1 hover:bg-slate-50 rounded">
            <ChevronLeft className="w-6 h-6 text-[#00b4e5]" />
          </button>
          <h2 className="text-lg font-bold text-slate-800 capitalize">
            {MONTHS[currentDate.getMonth()]} {currentDate.getFullYear()}
          </h2>
          <button onClick={() => navigateMonth('next')} className="p-1 hover:bg-slate-50 rounded">
            <ChevronRight className="w-6 h-6 text-[#00b4e5]" />
          </button>
        </div>

        <div className="px-1 pb-1">
          <div className="grid grid-cols-7 border-t border-l border-slate-200">
            {['M', 'T', 'O', 'T', 'F', 'L', 'S'].map((d, i) => (
              <div key={i} className="text-center font-bold text-slate-900 py-3 text-xs border-r border-b border-slate-200 bg-[#fbfcfd]">
                {d}
              </div>
            ))}
            {daysInMonth.map((day, i) => {
              const totalHours = day ? getDayTotal(day) : 0;
              const isWeekend = day && (day.getDay() === 0 || day.getDay() === 6);
              const isFullDay = totalHours >= 8;
              
              return (
                <div 
                  key={i} 
                  onClick={() => day && handleDayClick(day)}
                  className={`min-h-[85px] p-2 border-r border-b border-slate-200 relative transition-colors duration-150 ${!day ? 'bg-[#fbfcfd]' : 'bg-white hover:bg-slate-50 cursor-pointer active:bg-blue-50'}`}
                >
                  {day && (
                    <>
                      <span className={`text-sm font-bold ${isWeekend ? 'text-[#f06292]' : 'text-slate-400'}`}>
                        {day.getDate()}
                      </span>
                      {totalHours > 0 && (
                        <div className="absolute inset-x-0 bottom-4 flex justify-center">
                          <div className={`
                            px-3 py-1.5 rounded text-xs font-black border min-w-[35px] text-center transition-all duration-300
                            ${isFullDay 
                              ? 'bg-emerald-100 text-emerald-700 border-emerald-200 scale-105 shadow-sm' 
                              : 'bg-[#ffe4e6] text-[#f06292] border-[#fecdd3]'
                            }
                          `}>
                            {totalHours}
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Quick Entry Modal */}
      {isModalOpen && selectedDay && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-200">
            <div className="bg-[#00b4e5] p-4 text-white flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                <h3 className="font-black uppercase tracking-wide text-sm">Rapportera Tid - {formatDate(selectedDay)}</h3>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="hover:bg-white/20 p-1 rounded-full transition-colors">
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="p-6 max-h-[70vh] overflow-y-auto">
              {/* Existing Entries for this day */}
              {selectedDayEntries.length > 0 && (
                <div className="mb-6 space-y-3">
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Befintliga rapporter</h4>
                  {selectedDayEntries.map(entry => (
                    <div key={entry.id} className="flex items-center justify-between p-3 bg-slate-50 border border-slate-100 rounded group">
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-slate-700">{projects.find(p => p.id === entry.projectId)?.name}</span>
                        <span className="text-[10px] text-slate-400">{entry.workerName} • {entry.workType}</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className={`font-black ${entry.hours >= 8 ? 'text-emerald-600' : 'text-[#f06292]'}`}>{entry.hours}h</span>
                        <button onClick={() => onDeleteEntry(entry.id)} className="text-slate-300 hover:text-red-500 transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Add New Entry Form */}
              <form onSubmit={handleModalSubmit} className="space-y-4">
                <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Ny rapport</h4>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2 sm:col-span-1">
                    <label className={labelClasses}>Medarbetare</label>
                    <select value={formWorkerName} onChange={e => setFormWorkerName(e.target.value)} className={inputClasses}>
                      {workers.map(w => <option key={w.id} value={w.name}>{w.name}</option>)}
                    </select>
                  </div>
                  <div className="col-span-2 sm:col-span-1">
                    <label className={labelClasses}>Antal timmar</label>
                    <input 
                      type="number" 
                      step="0.5" 
                      value={formHours} 
                      onChange={e => setFormHours(e.target.value)} 
                      className={inputClasses} 
                    />
                  </div>
                </div>

                <div>
                  <label className={labelClasses}>Projekt</label>
                  <select value={formProjectId} onChange={e => setFormProjectId(e.target.value)} className={inputClasses}>
                    {projects.map(p => <option key={p.id} value={p.id}>{p.name} ({p.code})</option>)}
                  </select>
                </div>

                <div>
                  <label className={labelClasses}>Arbetstyp</label>
                  <select value={formWorkType} onChange={e => setFormWorkType(e.target.value as WorkType)} className={inputClasses}>
                    {WORK_TYPES.map(type => <option key={type} value={type}>{type}</option>)}
                  </select>
                </div>

                <div>
                  <label className={labelClasses}>Beskrivning</label>
                  <textarea 
                    value={formDescription} 
                    onChange={e => setFormDescription(e.target.value)} 
                    className={`${inputClasses} h-20 resize-none py-2`} 
                    placeholder="Vad har utförts?"
                  />
                </div>

                <button type="submit" className="w-full bg-[#00b4e5] hover:bg-[#0096bf] text-white font-black py-3 rounded text-sm transition-all shadow-md flex items-center justify-center gap-2">
                  <Plus className="w-4 h-4" /> Lägg till rapport
                </button>
              </form>
            </div>
            
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
              <button 
                onClick={() => setIsModalOpen(false)}
                className="text-slate-500 font-bold text-sm hover:text-slate-800 transition-colors"
              >
                Stäng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Filter Section */}
      <div className="bg-white p-6 rounded shadow-sm border border-slate-200">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className={labelClasses}>År</label>
            <select value={filterYear} onChange={e => setFilterYear(e.target.value)} className={inputClasses}>
              <option value="2025">2025</option>
              <option value="2026">2026</option>
            </select>
          </div>
          <div>
            <label className={labelClasses}>Månad</label>
            <select value={filterMonth} onChange={e => setFilterMonth(e.target.value)} className={inputClasses}>
              {MONTHS.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
        </div>

        <div className="mb-6">
          <label className={labelClasses}>Vecka</label>
          <select value={filterWeek} onChange={e => setFilterWeek(e.target.value)} className={inputClasses}>
            <option value="">Välj vecka</option>
            {[...Array(52)].map((_, i) => (
              <option key={i+1} value={String(i + 1)}>Vecka {i+1}</option>
            ))}
          </select>
        </div>

        <button className="w-full bg-[#00b4e5] hover:bg-[#0096bf] text-white font-black py-4 rounded text-sm transition-all shadow-sm active:scale-[0.99] uppercase tracking-wide flex items-center justify-center gap-2">
          Visa rapporter
        </button>
      </div>
    </div>
  );
};

export default ReportedSummary;
