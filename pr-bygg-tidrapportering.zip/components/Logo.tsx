
import React from 'react';

interface Props {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

const Logo: React.FC<Props> = ({ className = "", size = "md" }) => {
  const scale = size === 'sm' ? 0.5 : size === 'lg' ? 1.2 : 0.8;
  const width = 300 * scale;
  const height = 350 * scale;

  return (
    <div className={`flex flex-col items-center ${className}`}>
      <svg 
        width={width} 
        height={height * 0.7} 
        viewBox="0 0 300 250" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        className="drop-shadow-md"
      >
        {/* Karaktär P */}
        <g transform="translate(40, 50)">
          {/* Ben och fötter */}
          <path d="M40 120 L40 150" stroke="black" strokeWidth="8" strokeLinecap="round" />
          <path d="M70 120 L70 150" stroke="black" strokeWidth="8" strokeLinecap="round" />
          <ellipse cx="35" cy="155" rx="20" ry="10" fill="#FACC15" stroke="black" strokeWidth="3" />
          <ellipse cx="75" cy="155" rx="20" ry="10" fill="#FACC15" stroke="black" strokeWidth="3" />
          
          {/* Kropp P */}
          <path d="M30 20 V120 H60 V80 H80 C110 80 110 20 80 20 H30Z" fill="#1E40AF" stroke="black" strokeWidth="4" />
          <path d="M60 40 H75 C85 40 85 60 75 60 H60 V40Z" fill="white" opacity="0.2" />
          
          {/* Ansikte */}
          <ellipse cx="65" cy="50" rx="6" ry="10" fill="white" stroke="black" strokeWidth="2" />
          <ellipse cx="85" cy="50" rx="6" ry="10" fill="white" stroke="black" strokeWidth="2" />
          <circle cx="67" cy="52" r="3" fill="black" />
          <circle cx="87" cy="52" r="3" fill="black" />
          <path d="M70 70 Q80 85 90 70" fill="#EF4444" stroke="black" strokeWidth="2" />
          
          {/* Hjälm */}
          <path d="M25 25 Q60 -10 100 25 L105 30 L20 30 Z" fill="#FACC15" stroke="black" strokeWidth="3" />
          <path d="M40 5 Q60 -5 80 5" stroke="black" strokeWidth="2" fill="none" />
          
          {/* Arm med hammare */}
          <path d="M30 60 L-10 40" stroke="black" strokeWidth="8" strokeLinecap="round" />
          <circle cx="-10" cy="40" r="12" fill="white" stroke="black" strokeWidth="2" />
          <g transform="translate(-15, 10) rotate(-30)">
            <rect x="0" y="0" width="8" height="40" fill="#78350F" stroke="black" strokeWidth="2" />
            <path d="M-10 -5 H18 V10 H-10 Z" fill="#374151" stroke="black" strokeWidth="2" />
          </g>
        </g>

        {/* Karaktär R */}
        <g transform="translate(160, 50)">
          {/* Ben och fötter */}
          <path d="M40 120 L40 150" stroke="black" strokeWidth="8" strokeLinecap="round" />
          <path d="M70 120 L100 150" stroke="black" strokeWidth="8" strokeLinecap="round" />
          <ellipse cx="35" cy="155" rx="20" ry="10" fill="#FACC15" stroke="black" strokeWidth="3" />
          <ellipse cx="105" cy="155" rx="20" ry="10" fill="#FACC15" stroke="black" strokeWidth="3" />
          
          {/* Kropp R */}
          <path d="M30 20 V120 H60 V80 L90 120 H120 L85 75 C105 70 105 20 75 20 H30Z" fill="#1E40AF" stroke="black" strokeWidth="4" />
          
          {/* Ansikte */}
          <ellipse cx="55" cy="45" rx="6" ry="10" fill="white" stroke="black" strokeWidth="2" />
          <ellipse cx="75" cy="45" rx="6" ry="10" fill="white" stroke="black" strokeWidth="2" />
          <circle cx="57" cy="47" r="3" fill="black" />
          <circle cx="77" cy="47" r="3" fill="black" />
          <path d="M60 65 Q70 80 80 65" fill="#EF4444" stroke="black" strokeWidth="2" />
          
          {/* Hjälm */}
          <path d="M25 25 Q60 -10 100 25 L105 30 L20 30 Z" fill="#FACC15" stroke="black" strokeWidth="3" />
          
          {/* Arm med kakel */}
          <path d="M100 70 L130 60" stroke="black" strokeWidth="8" strokeLinecap="round" />
          <circle cx="130" cy="60" r="12" fill="white" stroke="black" strokeWidth="2" />
          <rect x="135" y="35" width="30" height="30" fill="white" stroke="black" strokeWidth="2" />
          <rect x="135" y="35" width="15" height="15" fill="black" />
          <rect x="150" y="50" width="15" height="15" fill="black" />
        </g>
      </svg>
      
      {/* Text Branding */}
      <div className="text-center mt-2 flex flex-col items-center">
        <span className="text-[#102A50] font-black text-4xl leading-none tracking-tighter">PRBYGG</span>
        <div className="flex items-center gap-2 w-full px-4">
          <div className="h-[2px] bg-[#102A50] flex-1"></div>
          <span className="text-[#102A50] font-bold text-lg leading-none">OCH</span>
          <div className="h-[2px] bg-[#102A50] flex-1"></div>
        </div>
        <span className="text-[#102A50] font-black text-5xl leading-none tracking-tighter mt-1">KAKEL</span>
      </div>
    </div>
  );
};

export default Logo;
