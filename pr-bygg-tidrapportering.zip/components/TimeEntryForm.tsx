
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { WORK_TYPES } from '../constants';
import { WorkType, TimeEntry, Project, Worker } from '../types';
import { Calendar as CalendarIcon, Clock, ClipboardList, HardHat, User, ChevronUp, ChevronDown, CalendarDays } from 'lucide-react';

interface Props {
  projects: Project[];
  workers: Worker[];
  onSubmit: (entry: Omit<TimeEntry, 'id'>) => void;
}

const MONTHS = [
  'januari', 'februari', 'mars', 'april', 'maj', 'juni',
  'juli', 'augusti', 'september', 'oktober', 'november', 'december'
];

const formatDate = (date: Date) => {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

const TimeEntryForm: React.FC<Props> = ({ projects, workers, onSubmit }) => {
  const [projectId, setProjectId] = useState(projects[0]?.id || '');
  const [date, setDate] = useState(formatDate(new Date()));
  const [hours, setHours] = useState('8');
  const [workType, setWorkType] = useState<WorkType>(WorkType.NORMAL);
  const [description, setDescription] = useState('');
  const [workerName, setWorkerName] = useState(workers[0]?.name || '');

  // Custom Calendar State
  const [showCalendar, setShowCalendar] = useState(false);
  const [viewDate, setViewDate] = useState(new Date()); 
  const calendarRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (calendarRef.current && !calendarRef.current.contains(event.target as Node)) {
        setShowCalendar(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const calendarDays = useMemo(() => {
    const year = viewDate.getFullYear();
    const month = viewDate.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    
    let startOffset = firstDay.getDay();
    startOffset = startOffset === 0 ? 6 : startOffset - 1;

    const days = [];
    const prevMonthLastDay = new Date(year, month, 0).getDate();
    
    for (let i = startOffset - 1; i >= 0; i--) {
      days.push({ day: prevMonthLastDay - i, currentMonth: false, date: new Date(year, month - 1, prevMonthLastDay - i) });
    }

    for (let i = 1; i <= lastDay.getDate(); i++) {
      days.push({ day: i, currentMonth: true, date: new Date(year, month, i) });
    }

    const remaining = 42 - days.length;
    for (let i = 1; i <= remaining; i++) {
      days.push({ day: i, currentMonth: false, date: new Date(year, month + 1, i) });
    }

    return days;
  }, [viewDate]);

  const handleCopyLast = () => {
    const savedEntries = JSON.parse(localStorage.getItem('bygg_entries') || '[]');
    if (savedEntries.length > 0) {
      const last = savedEntries[0];
      setProjectId(last.projectId);
      setHours(last.hours.toString());
      setWorkType(last.workType);
      setWorkerName(last.workerName);
      setDescription(last.description);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!projectId || !workerName) return;
    onSubmit({
      projectId,
      date,
      hours: parseFloat(hours),
      workType,
      description,
      workerName
    });
    // Vi rensar beskrivningen men behåller projekt/namn för snabbare nästa rapport
    setDescription('');
  };

  const handleDaySelect = (d: Date) => {
    setDate(formatDate(d));
    setShowCalendar(false);
  };

  const changeMonth = (delta: number) => {
    setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() + delta, 1));
  };

  const inputClasses = "w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#102A50] outline-none bg-white text-slate-900 placeholder:text-slate-400 appearance-none font-medium transition-all shadow-sm";
  const labelClasses = "block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 flex items-center gap-2";

  return (
    <form onSubmit={handleSubmit} className="bg-white p-8 rounded-3xl shadow-xl border border-slate-100 relative">
      <h2 className="text-xl font-black mb-8 flex items-center gap-3 text-[#102A50] uppercase tracking-tight">
        <HardHat className="w-6 h-6 text-[#102A50]" />
        Ny Tidrapport
      </h2>
      
      <div className="space-y-6">
        <div>
          <label className={labelClasses}>
            <User className="w-3 h-3" /> Anställd
          </label>
          <select
            value={workerName}
            onChange={(e) => setWorkerName(e.target.value)}
            className={inputClasses}
          >
            {workers.map(w => (
              <option key={w.id} value={w.name}>{w.name}</option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-end relative">
          <div className="md:col-span-3">
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <CalendarIcon className="w-3 h-3" /> Datum
              </label>
              <button 
                type="button" 
                onClick={handleCopyLast}
                className="text-[10px] font-black text-[#102A50] hover:underline uppercase tracking-tighter"
              >
                Kopiera föregående
              </button>
            </div>
            <div className="relative">
              <div 
                onClick={() => setShowCalendar(!showCalendar)}
                className={`${inputClasses} cursor-pointer flex justify-between items-center min-h-[42px]`}
              >
                <span className="text-sm font-bold">{date || 'Välj datum'}</span>
                <CalendarDays className="w-5 h-5 text-[#102A50]" />
              </div>

              {showCalendar && (
                <div ref={calendarRef} className="absolute top-full left-0 mt-2 z-[110] bg-white border border-slate-200 rounded-2xl shadow-2xl w-80 overflow-hidden">
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-4 px-1">
                      <span className="font-black text-[#102A50] capitalize text-sm">{MONTHS[viewDate.getMonth()]} {viewDate.getFullYear()}</span>
                      <div className="flex gap-2">
                        <button type="button" onClick={() => changeMonth(-1)} className="p-1 hover:bg-slate-100 rounded-full transition-colors"><ChevronUp className="w-4 h-4" /></button>
                        <button type="button" onClick={() => changeMonth(1)} className="p-1 hover:bg-slate-100 rounded-full transition-colors"><ChevronDown className="w-4 h-4" /></button>
                      </div>
                    </div>

                    <div className="grid grid-cols-7 gap-1 mb-2">
                      {['M', 'T', 'O', 'T', 'F', 'L', 'S'].map(d => (
                        <div key={d} className="text-center text-[10px] font-black text-slate-300 py-1">{d}</div>
                      ))}
                      {calendarDays.map((d, i) => {
                        const isSelected = formatDate(d.date) === date;
                        const isToday = formatDate(d.date) === formatDate(new Date());
                        return (
                          <div 
                            key={i}
                            onClick={() => handleDaySelect(d.date)}
                            className={`
                              h-9 flex items-center justify-center text-xs font-bold cursor-pointer transition-all rounded-lg
                              ${isSelected ? 'bg-[#102A50] text-white' : d.currentMonth ? 'text-slate-700 hover:bg-slate-100' : 'text-slate-200'}
                              ${isToday && !isSelected ? 'border border-[#102A50] text-[#102A50]' : ''}
                            `}
                          >
                            {d.day}
                          </div>
                        );
                      })}
                    </div>

                    <div className="flex justify-between items-center pt-3 border-t border-slate-50 px-1">
                      <button type="button" onClick={() => { setDate(''); setShowCalendar(false); }} className="text-[10px] font-black text-slate-400 hover:text-red-500 uppercase tracking-widest">Rensa</button>
                      <button type="button" onClick={() => { handleDaySelect(new Date()); }} className="text-[10px] font-black text-[#102A50] hover:underline uppercase tracking-widest">I dag</button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div className="md:col-span-1">
            <div className="relative">
              <label className="md:hidden text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 flex items-center gap-1"><Clock className="w-3 h-3"/> Timmar</label>
              <input
                type="number"
                step="0.5"
                value={hours}
                onChange={(e) => setHours(e.target.value)}
                className={inputClasses}
              />
            </div>
          </div>
        </div>

        <div>
          <label className={labelClasses}>Projekt</label>
          <select
            value={projectId}
            onChange={(e) => setProjectId(e.target.value)}
            className={inputClasses}
          >
            {projects.map(p => (
              <option key={p.id} value={p.id}>{p.name} ({p.code})</option>
            ))}
          </select>
        </div>

        <div>
          <label className={labelClasses}>Typ av arbete</label>
          <select
            value={workType}
            onChange={(e) => setWorkType(e.target.value as WorkType)}
            className={inputClasses}
          >
            {WORK_TYPES.map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>

        <div>
          <label className={labelClasses}>
            <ClipboardList className="w-3 h-3" /> Beskrivning
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className={`${inputClasses} h-28 resize-none py-3`}
            placeholder="Beskriv vad du gjort..."
          ></textarea>
        </div>

        <button
          type="submit"
          className="w-full bg-[#102A50] text-white font-black py-4 rounded-2xl shadow-lg hover:shadow-[#102A50]/20 transition-all uppercase tracking-widest text-sm flex items-center justify-center gap-3 active:scale-[0.98]"
        >
          Spara Tidrapport
        </button>
      </div>
    </form>
  );
};

export default TimeEntryForm;
