
import React, { useMemo, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { TimeEntry, Project, MaterialCost, AIAnalysis } from '../types';
import AIAnalysisPanel from './AIAnalysisPanel';
import { analyzeTimeReports } from '../services/geminiService';
import { Package, Clock, TrendingUp } from 'lucide-react';

interface Props {
  entries: TimeEntry[];
  projects: Project[];
  materialCosts: MaterialCost[];
}

const COLORS = ['#102A50', '#f59e0b', '#3b82f6', '#10b981', '#ef4444', '#8b5cf6'];

const Dashboard: React.FC<Props> = ({ entries, projects, materialCosts }) => {
  const [analysis, setAnalysis] = useState<AIAnalysis | null>(() => {
    const saved = localStorage.getItem('bygg_ai_analysis');
    return saved ? JSON.parse(saved) : null;
  });
  const [loading, setLoading] = useState(false);

  const handleRefreshAnalysis = async () => {
    setLoading(true);
    try {
      const result = await analyzeTimeReports(entries, projects);
      if (result) {
        setAnalysis(result);
        localStorage.setItem('bygg_ai_analysis', JSON.stringify(result));
      }
    } catch (error) {
      console.error("Analysis failed", error);
    } finally {
      setLoading(false);
    }
  };

  const projectStats = useMemo(() => {
    const stats: Record<string, { hours: number, material: number }> = {};
    projects.forEach(p => stats[p.name] = { hours: 0, material: 0 });
    
    entries.forEach(e => {
      const projectName = projects.find(p => p.id === e.projectId)?.name || 'Okänt';
      if (stats[projectName]) stats[projectName].hours += e.hours;
    });

    materialCosts.forEach(m => {
      const projectName = projects.find(p => p.id === m.projectId)?.name || 'Okänt';
      if (stats[projectName]) stats[projectName].material += m.amount;
    });

    return Object.entries(stats).map(([name, data]) => ({ 
      name, 
      hours: data.hours, 
      material: data.material 
    }));
  }, [entries, projects, materialCosts]);

  const totalHours = entries.reduce((acc, curr) => acc + curr.hours, 0);
  const totalMaterial = materialCosts.reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center gap-2 mb-1">
            <Clock className="w-3 h-3 text-slate-400" />
            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Totaltid</p>
          </div>
          <p className="text-4xl font-black text-[#102A50]">{totalHours} <span className="text-sm font-bold text-slate-300">h</span></p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center gap-2 mb-1">
            <Package className="w-3 h-3 text-amber-500" />
            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Materialkostnad</p>
          </div>
          <p className="text-4xl font-black text-amber-600">{totalMaterial.toLocaleString()} <span className="text-sm font-bold text-slate-300">kr</span></p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="w-3 h-3 text-emerald-500" />
            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Antal inköp</p>
          </div>
          <p className="text-4xl font-black text-[#102A50]">{materialCosts.length} <span className="text-sm font-bold text-slate-300">st</span></p>
        </div>
      </div>

      <AIAnalysisPanel 
        analysis={analysis} 
        loading={loading} 
        onRefresh={handleRefreshAnalysis} 
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200">
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest mb-8">Timmar per projekt</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={projectStats}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" fontSize={10} fontWeight="bold" axisLine={false} tickLine={false} />
                <YAxis fontSize={10} fontWeight="bold" axisLine={false} tickLine={false} />
                <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                <Bar dataKey="hours" fill="#102A50" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200">
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest mb-8 text-amber-600">Materialkostnad per projekt</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={projectStats}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" fontSize={10} fontWeight="bold" axisLine={false} tickLine={false} />
                <YAxis fontSize={10} fontWeight="bold" axisLine={false} tickLine={false} />
                <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                <Bar dataKey="material" fill="#f59e0b" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
