
import React, { useState, useMemo } from 'react';
import { Project, TimeEntry, MaterialCost } from '../types';
import { Trash2, Edit2, Check, X, Clock, User, Calendar, ArrowUp, ArrowDown, ArrowUpDown, Package, Eye, FileText } from 'lucide-react';

interface Props {
  project: Project;
  entries: TimeEntry[];
  materialCosts: MaterialCost[];
  onDeleteEntry: (id: string) => void;
  onUpdateEntry: (id: string, updates: Partial<TimeEntry>) => void;
}

type SortField = 'date' | 'workerName' | 'hours';

const ProjectLogDetail: React.FC<Props> = ({ project, entries, materialCosts, onDeleteEntry, onUpdateEntry }) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editHours, setEditHours] = useState<string>('');
  const [editDate, setEditDate] = useState<string>('');
  
  // Sorting State
  const [sortField, setSortField] = useState<SortField>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const sortedEntries = useMemo(() => {
    return [...entries].sort((a, b) => {
      let comparison = 0;
      
      if (sortField === 'date') {
        comparison = a.date.localeCompare(b.date);
      } else if (sortField === 'workerName') {
        comparison = a.workerName.localeCompare(b.workerName);
      } else if (sortField === 'hours') {
        comparison = a.hours - b.hours;
      }

      return sortOrder === 'desc' ? -comparison : comparison;
    });
  }, [entries, sortField, sortOrder]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder(field === 'workerName' ? 'asc' : 'desc');
    }
  };

  const startEdit = (entry: TimeEntry) => {
    setEditingId(entry.id);
    setEditHours(entry.hours.toString());
    setEditDate(entry.date);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditHours('');
    setEditDate('');
  };

  const saveEdit = (id: string) => {
    const hoursVal = parseFloat(editHours);
    const updates: Partial<TimeEntry> = {
      date: editDate
    };
    if (!isNaN(hoursVal)) {
      updates.hours = hoursVal;
    }
    onUpdateEntry(id, updates);
    setEditingId(null);
  };

  const viewPdf = (fileData: string) => {
    const newWindow = window.open();
    if (newWindow) {
      newWindow.document.write(`<iframe src="${fileData}" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>`);
    }
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ArrowUpDown className="w-3.5 h-3.5 text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity" />;
    return sortOrder === 'desc' 
      ? <ArrowDown className="w-3.5 h-3.5 text-[#102A50]" /> 
      : <ArrowUp className="w-3.5 h-3.5 text-[#102A50]" />;
  };

  const headerClasses = "px-6 py-4 cursor-pointer hover:bg-slate-100 transition-all group select-none relative";

  const totalHours = entries.reduce((sum, e) => sum + e.hours, 0);
  const totalMaterial = materialCosts.reduce((sum, m) => sum + m.amount, 0);

  return (
    <div className="space-y-8">
      {/* Project Overview Card */}
      <div className="bg-white rounded-3xl shadow-xl border border-slate-200 overflow-hidden">
        <div className="p-8 bg-slate-50 border-b border-slate-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className="text-[10px] font-black tracking-widest text-[#102A50] bg-white px-3 py-1 rounded-full border border-slate-200 uppercase">
                  {project.code}
                </span>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">{project.location}</span>
              </div>
              <h2 className="text-3xl font-black text-[#102A50] uppercase tracking-tight">{project.name}</h2>
            </div>
            <div className="flex gap-4">
              <div className="text-right bg-white p-4 rounded-2xl border border-slate-200 shadow-sm min-w-[140px]">
                <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest mb-1">Ack. Projekt-tid</p>
                <p className="text-3xl font-black text-[#102A50]">
                  {totalHours} <span className="text-sm font-bold text-slate-400 uppercase">H</span>
                </p>
              </div>
              <div className="text-right bg-white p-4 rounded-2xl border border-amber-100 shadow-sm min-w-[140px]">
                <p className="text-[10px] text-amber-400 uppercase font-black tracking-widest mb-1">Ack. Material</p>
                <p className="text-2xl font-black text-amber-600">
                  {totalMaterial.toLocaleString()} <span className="text-xs font-bold text-amber-300 uppercase font-bold">kr</span>
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Time Entries Table */}
        <div className="overflow-x-auto">
          <div className="p-6 bg-slate-50/30 border-b border-slate-100">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
              <Clock className="w-4 h-4" /> Tidrapportering
            </h3>
          </div>
          <table className="w-full text-left">
            <thead>
              <tr className="bg-white text-slate-400 text-[10px] uppercase font-black tracking-widest border-b border-slate-100">
                <th className={`${headerClasses} ${sortField === 'date' ? 'bg-slate-50/50' : ''}`} onClick={() => handleSort('date')}>
                  <div className="flex items-center gap-2">Datum <SortIcon field="date" /></div>
                </th>
                <th className={`${headerClasses} ${sortField === 'workerName' ? 'bg-slate-50/50' : ''}`} onClick={() => handleSort('workerName')}>
                  <div className="flex items-center gap-2">Medarbetare <SortIcon field="workerName" /></div>
                </th>
                <th className="px-6 py-4">Arbetstyp</th>
                <th className="px-6 py-4">Beskrivning</th>
                <th className={`${headerClasses} ${sortField === 'hours' ? 'bg-slate-50/50' : ''}`} onClick={() => handleSort('hours')}>
                  <div className="flex items-center gap-2">Tid <SortIcon field="hours" /></div>
                </th>
                <th className="px-6 py-4 text-right">Åtgärder</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {sortedEntries.length === 0 ? (
                <tr><td colSpan={6} className="px-6 py-12 text-center text-slate-300 text-xs font-bold italic uppercase tracking-widest">Inga rapporterade timmar</td></tr>
              ) : (
                sortedEntries.map((entry) => (
                  <tr key={entry.id} className="hover:bg-slate-50 transition-colors group">
                    <td className="px-6 py-5 text-sm font-bold text-slate-600">{entry.date}</td>
                    <td className="px-6 py-5 text-sm font-bold text-slate-600">{entry.workerName}</td>
                    <td className="px-6 py-5">
                      <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full border bg-slate-50">{entry.workType}</span>
                    </td>
                    <td className="px-6 py-5 text-xs text-slate-400 font-medium max-w-xs truncate">{entry.description || '-'}</td>
                    <td className="px-6 py-5 font-black text-lg text-slate-900">{entry.hours}h</td>
                    <td className="px-6 py-5 text-right">
                      <button onClick={() => onDeleteEntry(entry.id)} className="p-2 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"><Trash2 className="w-4 h-4" /></button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Materials List Card */}
      <div className="bg-white rounded-3xl shadow-xl border border-slate-200 overflow-hidden">
        <div className="p-6 bg-amber-50/30 border-b border-amber-100 flex items-center justify-between">
          <h3 className="text-xs font-black text-amber-600 uppercase tracking-[0.2em] flex items-center gap-2">
            <Package className="w-4 h-4" /> Materialinköp
          </h3>
          <span className="text-xs font-black text-amber-700 bg-amber-100 px-3 py-1 rounded-full">{materialCosts.length} st</span>
        </div>
        <div className="divide-y divide-slate-50">
          {materialCosts.length === 0 ? (
            <div className="p-12 text-center text-slate-300 uppercase font-black text-xs tracking-widest">Inga materialinköp registrerade</div>
          ) : (
            materialCosts.map(cost => (
              <div key={cost.id} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center text-amber-500"><Package className="w-5 h-5" /></div>
                  <div>
                    <h4 className="font-black text-[#102A50] uppercase text-sm flex items-center gap-2">
                      {cost.description}
                      {cost.fileData && <span className="bg-amber-100 text-amber-600 text-[8px] px-1.5 py-0.5 rounded-full font-black">PDF</span>}
                    </h4>
                    <p className="text-[10px] text-slate-400 font-bold uppercase">{cost.date} • {cost.workerName}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-black text-amber-600 text-lg">{cost.amount.toLocaleString()} kr</span>
                  {cost.fileData && (
                    <button onClick={() => viewPdf(cost.fileData!)} className="p-2 text-slate-400 hover:text-amber-500 transition-all"><Eye className="w-5 h-5" /></button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default ProjectLogDetail;
