
import React, { useState } from 'react';
import { User } from '../types';
import { Mail, Lock, User as UserIcon, ArrowRight, HardHat } from 'lucide-react';
import Logo from './Logo';

interface Props {
  onLogin: (user: User) => void;
}

const AuthPage: React.FC<Props> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const storedUsers = JSON.parse(localStorage.getItem('bygg_users') || '[]');

    if (isLogin) {
      const user = storedUsers.find((u: any) => u.email === email && u.password === password);
      if (user) {
        onLogin(user);
      } else {
        setError('Fel e-postadress eller lösenord.');
      }
    } else {
      if (!name || !email || !password) {
        setError('Vänligen fyll i alla fält.');
        return;
      }
      
      if (storedUsers.some((u: any) => u.email === email)) {
        setError('E-postadressen används redan.');
        return;
      }

      const newUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        email,
        name,
        password
      };

      const updatedUsers = [...storedUsers, newUser];
      localStorage.setItem('bygg_users', JSON.stringify(updatedUsers));
      onLogin(newUser);
    }
  };

  const inputBaseClasses = "w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-[#102A50] outline-none transition-all font-medium text-slate-900";

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col justify-center items-center p-4">
      {/* Dynamic SVG Logo based on user upload */}
      <div className="mb-10 scale-110">
        <Logo size="lg" />
      </div>

      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden transform transition-all">
        <div className="bg-[#102A50] p-6 text-white text-center">
          <h2 className="text-xl font-black uppercase tracking-widest">
            {isLogin ? 'Logga in i systemet' : 'Skapa nytt medarbetarkonto'}
          </h2>
          <p className="text-white/70 text-xs mt-2 font-bold uppercase tracking-tighter">
            Digital Projektstyrning för Proffs
          </p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          {error && (
            <div className="bg-red-50 border-l-4 border-red-500 p-4 text-red-700 text-sm font-bold animate-pulse">
              {error}
            </div>
          )}

          {!isLogin && (
            <div className="space-y-1">
              <label className="text-xs font-black text-slate-500 uppercase flex items-center gap-2">
                <UserIcon className="w-3 h-3" /> Fullständigt namn
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className={inputBaseClasses}
                placeholder="Namn Namnsson"
              />
            </div>
          )}

          <div className="space-y-1">
            <label className="text-xs font-black text-slate-500 uppercase flex items-center gap-2">
              <Mail className="w-3 h-3" /> E-postadress
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={inputBaseClasses}
              placeholder="namn@prbygg.se"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-black text-slate-500 uppercase flex items-center gap-2">
              <Lock className="w-3 h-3" /> Lösenord
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={inputBaseClasses}
              placeholder="••••••••"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-[#102A50] hover:bg-[#1a3a6b] text-white font-black py-4 rounded-xl shadow-lg hover:shadow-[#102A50]/30 transition-all uppercase tracking-widest text-sm flex items-center justify-center gap-3 group"
          >
            {isLogin ? 'Logga in' : 'Skapa konto'}
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </form>

        <div className="px-8 pb-8 text-center">
          <button
            onClick={() => { setIsLogin(!isLogin); setError(''); }}
            className="text-slate-400 text-xs font-bold hover:text-[#102A50] transition-colors uppercase tracking-widest"
          >
            {isLogin ? 'Inget konto? Registrera dig här' : 'Har du redan ett konto? Logga in'}
          </button>
        </div>
      </div>
      
      <div className="mt-8 flex items-center gap-2 text-slate-400">
        <HardHat className="w-4 h-4" />
        <span className="text-[10px] font-black uppercase tracking-widest">ByggKoll Management v2.5 • PR BYGG</span>
      </div>
    </div>
  );
};

export default AuthPage;
