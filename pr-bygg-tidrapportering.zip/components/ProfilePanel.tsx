
import React, { useState } from 'react';
import { User } from '../types';
import { User as UserIcon, Lock, ShieldCheck, Save, AlertCircle, CheckCircle2 } from 'lucide-react';

interface Props {
  user: User;
  onUpdateUser: (updatedUser: User) => void;
}

const ProfilePanel: React.FC<Props> = ({ user, onUpdateUser }) => {
  const [name, setName] = useState(user.name);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setMessage(null);

    // Hämta alla användare för att kunna uppdatera rätt i "databasen"
    const storedUsers = JSON.parse(localStorage.getItem('bygg_users') || '[]');
    const userIdx = storedUsers.findIndex((u: User) => u.id === user.id);

    if (userIdx === -1) {
      setMessage({ type: 'error', text: 'Kunde inte hitta användaren i databasen.' });
      return;
    }

    // Om man försöker byta lösenord
    if (newPassword || currentPassword) {
      if (currentPassword !== user.password) {
        setMessage({ type: 'error', text: 'Nuvarande lösenord är felaktigt.' });
        return;
      }
      if (newPassword !== confirmPassword) {
        setMessage({ type: 'error', text: 'Nya lösenorden matchar inte.' });
        return;
      }
      if (newPassword.length < 4) {
        setMessage({ type: 'error', text: 'Det nya lösenordet måste vara minst 4 tecken.' });
        return;
      }
    }

    const updatedUser: User = {
      ...user,
      name,
      password: newPassword || user.password
    };

    // Spara i localStorage (simulerad DB)
    storedUsers[userIdx] = updatedUser;
    localStorage.setItem('bygg_users', JSON.stringify(storedUsers));

    // Uppdatera sessionen
    onUpdateUser(updatedUser);
    
    setMessage({ type: 'success', text: 'Din profil har uppdaterats korrekt!' });
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
  };

  const inputClasses = "w-full px-4 py-3 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-[#00b4e5] outline-none transition-all font-medium text-slate-900";
  const labelClasses = "text-xs font-black text-slate-500 uppercase flex items-center gap-2 mb-1.5";

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden">
        <div className="bg-gradient-to-r from-slate-800 to-slate-900 p-8 text-white">
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 bg-[#00b4e5] rounded-2xl flex items-center justify-center shadow-lg transform -rotate-3 border-4 border-white/10">
              <UserIcon className="w-10 h-10 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black uppercase tracking-tight">{user.name}</h2>
              <p className="text-slate-400 font-bold text-sm">{user.email}</p>
              <div className="flex gap-2 mt-2">
                <span className="bg-white/10 text-white/70 px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest border border-white/5">Medarbetare</span>
                <span className="bg-green-500/20 text-green-400 px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest border border-green-500/20">Aktiv</span>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleUpdateProfile} className="p-8 space-y-8">
          {message && (
            <div className={`p-4 rounded-lg flex items-center gap-3 font-bold text-sm animate-in fade-in slide-in-from-top-2 ${
              message.type === 'success' ? 'bg-green-50 text-green-700 border border-green-100' : 'bg-red-50 text-red-700 border border-red-100'
            }`}>
              {message.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
              {message.text}
            </div>
          )}

          <section>
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest mb-4 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#00b4e5]" /> Grunduppgifter
            </h3>
            <div className="space-y-4">
              <div>
                <label className={labelClasses}>Fullständigt namn</label>
                <input 
                  type="text" 
                  value={name} 
                  onChange={(e) => setName(e.target.value)}
                  className={inputClasses}
                  placeholder="Namn Namnsson"
                />
              </div>
              <div>
                <label className={labelClasses}>E-post (kan ej ändras)</label>
                <input 
                  type="email" 
                  value={user.email} 
                  disabled
                  className={inputClasses + " bg-slate-50 text-slate-400 cursor-not-allowed"}
                />
              </div>
            </div>
          </section>

          <section className="pt-6 border-t border-slate-100">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest mb-4 flex items-center gap-2">
              <Lock className="w-4 h-4 text-amber-500" /> Säkerhet & Lösenord
            </h3>
            <div className="space-y-4">
              <div>
                <label className={labelClasses}>Nuvarande lösenord</label>
                <input 
                  type="password" 
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className={inputClasses}
                  placeholder="Skriv ditt nuvarande lösenord"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className={labelClasses}>Nytt lösenord</label>
                  <input 
                    type="password" 
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className={inputClasses}
                    placeholder="Minst 4 tecken"
                  />
                </div>
                <div>
                  <label className={labelClasses}>Bekräfta nytt lösenord</label>
                  <input 
                    type="password" 
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className={inputClasses}
                    placeholder="Upprepa lösenordet"
                  />
                </div>
              </div>
            </div>
          </section>

          <div className="pt-4">
            <button
              type="submit"
              className="w-full bg-[#00b4e5] hover:bg-[#0096bf] text-white font-black py-4 rounded-xl shadow-lg hover:shadow-[#00b4e5]/30 transition-all uppercase tracking-widest text-sm flex items-center justify-center gap-3 group"
            >
              <Save className="w-5 h-5 group-hover:scale-110 transition-transform" />
              Spara ändringar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProfilePanel;
