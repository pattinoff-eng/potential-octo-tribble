
import React, { useState, useRef } from 'react';
import { Project, Worker, MaterialCost } from '../types';
import { Package, Plus, Trash2, Calendar, User, DollarSign, Search, Tag, HardHat, FileText, Upload, Eye, X } from 'lucide-react';

interface Props {
  costs: MaterialCost[];
  projects: Project[];
  workers: Worker[];
  onAdd: (cost: Omit<MaterialCost, 'id'>) => void;
  onDelete: (id: string) => void;
}

const MaterialPanel: React.FC<Props> = ({ costs, projects, workers, onAdd, onDelete }) => {
  const [projectId, setProjectId] = useState(projects[0]?.id || '');
  const [workerName, setWorkerName] = useState(workers[0]?.name || '');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [searchTerm, setSearchTerm] = useState('');
  
  // File state
  const [selectedFile, setSelectedFile] = useState<{ name: string, data: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.type !== 'application/pdf') {
        alert('Vänligen välj en PDF-fil.');
        return;
      }
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedFile({
          name: file.name,
          data: reader.result as string
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!projectId || !description || !amount) return;
    
    onAdd({
      projectId,
      workerName,
      description,
      amount: parseFloat(amount),
      date,
      fileName: selectedFile?.name,
      fileData: selectedFile?.data
    });
    
    // Reset form
    setDescription('');
    setAmount('');
    setSelectedFile(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const viewPdf = (fileData: string) => {
    const newWindow = window.open();
    if (newWindow) {
      newWindow.document.write(`<iframe src="${fileData}" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>`);
    }
  };

  const filteredCosts = costs.filter(c => 
    projects.find(p => p.id === c.projectId)?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const inputClasses = "w-full px-4 py-2 border border-slate-200 rounded focus:ring-2 focus:ring-amber-500 outline-none bg-white text-slate-900 appearance-none font-medium text-sm";
  const labelClasses = "block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 flex items-center gap-1.5";

  const totalCost = filteredCosts.reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      {/* Summary Card */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Total materialkostnad</p>
          <p className="text-4xl font-black text-amber-600">{totalCost.toLocaleString()} <span className="text-sm font-bold text-slate-300">kr</span></p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Registrerade inköp</p>
          <p className="text-4xl font-black text-[#102A50]">{filteredCosts.length} <span className="text-sm font-bold text-slate-300">st</span></p>
        </div>
      </div>

      {/* Add Entry Card */}
      <div className="bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden">
        <div className="bg-amber-500 p-4 text-white flex items-center gap-3">
          <Package className="w-5 h-5" />
          <h2 className="font-black uppercase tracking-widest text-sm">Ny materialkostnad</h2>
        </div>
        <form onSubmit={handleSubmit} className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="md:col-span-2">
            <label className={labelClasses}><Tag className="w-3 h-3" /> Beskrivning / Artikel</label>
            <input 
              type="text" 
              placeholder="T.ex. 20 säckar flytspackel, Kakelfix..."
              className={inputClasses}
              value={description}
              onChange={e => setDescription(e.target.value)}
            />
          </div>
          
          <div>
            <label className={labelClasses}><HardHat className="w-3 h-3" /> Projekt</label>
            <select value={projectId} onChange={e => setProjectId(e.target.value)} className={inputClasses}>
              {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>

          <div>
            <label className={labelClasses}><DollarSign className="w-3 h-3" /> Belopp (exkl. moms)</label>
            <input 
              type="number" 
              placeholder="0.00"
              className={inputClasses}
              value={amount}
              onChange={e => setAmount(e.target.value)}
            />
          </div>

          <div>
            <label className={labelClasses}><Calendar className="w-3 h-3" /> Inköpsdatum</label>
            <input 
              type="date" 
              className={inputClasses}
              value={date}
              onChange={e => setDate(e.target.value)}
            />
          </div>

          <div>
            <label className={labelClasses}><User className="w-3 h-3" /> Inköpt av</label>
            <select value={workerName} onChange={e => setWorkerName(e.target.value)} className={inputClasses}>
              {workers.map(w => <option key={w.id} value={w.name}>{w.name}</option>)}
            </select>
          </div>

          {/* File Upload Section */}
          <div className="md:col-span-2">
            <label className={labelClasses}><FileText className="w-3 h-3" /> Bifoga Faktura (PDF)</label>
            <div 
              onClick={() => fileInputRef.current?.click()}
              className={`
                border-2 border-dashed rounded-xl p-4 flex flex-col items-center justify-center cursor-pointer transition-all
                ${selectedFile ? 'border-amber-500 bg-amber-50' : 'border-slate-200 hover:border-amber-400 hover:bg-slate-50'}
              `}
            >
              <input 
                type="file" 
                ref={fileInputRef}
                className="hidden" 
                accept="application/pdf"
                onChange={handleFileChange}
              />
              {selectedFile ? (
                <div className="flex items-center gap-3 w-full">
                  <div className="bg-amber-500 p-2 rounded-lg text-white">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-black text-amber-700 truncate">{selectedFile.name}</p>
                    <p className="text-[10px] text-amber-500 font-bold uppercase">Fil vald</p>
                  </div>
                  <button 
                    type="button"
                    onClick={(e) => { e.stopPropagation(); setSelectedFile(null); if(fileInputRef.current) fileInputRef.current.value = ''; }}
                    className="p-1.5 hover:bg-amber-200 rounded-full text-amber-600 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <>
                  <Upload className="w-6 h-6 text-slate-300 mb-2" />
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Klicka för att ladda upp underlag</p>
                </>
              )}
            </div>
          </div>

          <div className="md:col-span-2 pt-2">
            <button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-white font-black py-4 rounded-xl shadow-lg transition-all flex items-center justify-center gap-3 uppercase tracking-widest text-sm">
              <Plus className="w-5 h-5" /> Spara inköp
            </button>
          </div>
        </form>
      </div>

      {/* History List */}
      <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">Inköpshistorik</h3>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
            <input 
              type="text" 
              placeholder="Sök material..." 
              className="pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium outline-none focus:ring-2 focus:ring-amber-500 w-48"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div className="divide-y divide-slate-50">
          {filteredCosts.length === 0 ? (
            <div className="p-12 text-center text-slate-300">
              <Package className="w-12 h-12 mx-auto mb-4 opacity-10" />
              <p className="font-bold uppercase tracking-widest text-xs">Inga materialkostnader registrerade</p>
            </div>
          ) : (
            filteredCosts.map(cost => (
              <div key={cost.id} className="p-6 hover:bg-slate-50 transition-colors flex items-center justify-between group">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center text-amber-500">
                    <Package className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-black text-[#102A50] uppercase text-sm flex items-center gap-2">
                      {cost.description}
                      {cost.fileData && (
                        <span className="bg-amber-100 text-amber-600 text-[8px] px-1.5 py-0.5 rounded-full font-black uppercase">PDF</span>
                      )}
                    </h4>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">
                      {projects.find(p => p.id === cost.projectId)?.name} • {cost.date} • {cost.workerName}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right mr-4">
                    <span className="block font-black text-amber-600 text-lg leading-none">{cost.amount.toLocaleString()} kr</span>
                  </div>
                  
                  {cost.fileData && (
                    <button 
                      onClick={() => viewPdf(cost.fileData!)}
                      className="p-2 text-slate-400 hover:text-amber-500 hover:bg-amber-50 rounded-lg transition-all"
                      title="Visa PDF-faktura"
                    >
                      <Eye className="w-5 h-5" />
                    </button>
                  )}
                  
                  <button 
                    onClick={() => onDelete(cost.id)}
                    className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default MaterialPanel;
