
import React, { useState } from 'react';
import { Project, Worker, TimeEntry, MaterialCost } from '../types';
import { Trash2, Plus, Briefcase, Users, Download, Database } from 'lucide-react';

interface Props {
  projects: Project[];
  workers: Worker[];
  entries: TimeEntry[];
  materialCosts: MaterialCost[];
  onAddProject: (project: Omit<Project, 'id'>) => void;
  onRemoveProject: (id: string) => void;
  onAddWorker: (name: string) => void;
  onRemoveWorker: (id: string) => void;
}

const SettingsPanel: React.FC<Props> = ({ 
  projects, workers, entries, materialCosts, onAddProject, onRemoveProject, onAddWorker, onRemoveWorker 
}) => {
  const [newProj, setNewProj] = useState({ name: '', code: '', client: '', location: '' });
  const [newWorkerName, setNewWorkerName] = useState('');

  const handleProjSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProj.name || !newProj.code) return;
    onAddProject(newProj);
    setNewProj({ name: '', code: '', client: '', location: '' });
  };

  const handleWorkerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWorkerName) return;
    onAddWorker(newWorkerName);
    setNewWorkerName('');
  };

  const handleExportData = () => {
    const data = {
      projects,
      workers,
      entries,
      materialCosts,
      exportDate: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `byggkoll-export-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const inputClasses = "w-full px-4 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-amber-500 text-slate-900 bg-white placeholder:text-slate-400";
  const workerInputClasses = "flex-1 px-4 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 bg-white placeholder:text-slate-400";

  return (
    <div className="space-y-8">
      {/* Export Section */}
      <div className="bg-indigo-900 text-white rounded-xl p-6 shadow-lg flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-white/10 rounded-xl"><Database className="w-6 h-6 text-indigo-300" /></div>
          <div>
            <h3 className="font-black uppercase tracking-widest text-sm">Säkerhetskopiering</h3>
            <p className="text-xs text-indigo-200 font-bold">Exportera all din tidrapportering och materialdata till en JSON-fil.</p>
          </div>
        </div>
        <button 
          onClick={handleExportData}
          className="bg-white text-indigo-900 px-6 py-3 rounded-xl font-black uppercase text-xs flex items-center gap-2 hover:bg-indigo-50 transition-all shadow-md active:scale-95"
        >
          <Download className="w-4 h-4" /> Exportera Data
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        {/* Project Management */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-6 border-b border-slate-100 bg-slate-50 flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-amber-500" />
            <h3 className="font-bold text-slate-800 text-lg">Hantera Projekt</h3>
          </div>
          <div className="p-6 space-y-6">
            <form onSubmit={handleProjSubmit} className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <input 
                  type="text" 
                  placeholder="Projektnamn" 
                  className={inputClasses}
                  value={newProj.name}
                  onChange={e => setNewProj({...newProj, name: e.target.value})}
                />
              </div>
              <input 
                type="text" 
                placeholder="Kod (t.ex. P2024-01)" 
                className={inputClasses}
                value={newProj.code}
                onChange={e => setNewProj({...newProj, code: e.target.value})}
              />
              <input 
                type="text" 
                placeholder="Plats" 
                className={inputClasses}
                value={newProj.location}
                onChange={e => setNewProj({...newProj, location: e.target.value})}
              />
              <button className="col-span-2 bg-slate-900 text-white py-2 rounded-lg font-bold flex items-center justify-center gap-2 hover:bg-slate-800 transition">
                <Plus className="w-4 h-4" /> Lägg till Projekt
              </button>
            </form>

            <div className="divide-y divide-slate-100">
              {projects.map(p => (
                <div key={p.id} className="py-3 flex justify-between items-center group">
                  <div>
                    <p className="font-bold text-slate-900">{p.name}</p>
                    <p className="text-xs text-slate-500">{p.code} • {p.location}</p>
                  </div>
                  <button 
                    onClick={() => onRemoveProject(p.id)}
                    className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Worker Management */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-6 border-b border-slate-100 bg-slate-50 flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-500" />
            <h3 className="font-bold text-slate-800 text-lg">Hantera Personal</h3>
          </div>
          <div className="p-6 space-y-6">
            <form onSubmit={handleWorkerSubmit} className="flex gap-2">
              <input 
                type="text" 
                placeholder="Fullständigt namn" 
                className={workerInputClasses}
                value={newWorkerName}
                onChange={e => setNewWorkerName(e.target.value)}
              />
              <button className="bg-slate-900 text-white px-6 py-2 rounded-lg font-bold hover:bg-slate-800 transition flex items-center gap-2">
                <Plus className="w-4 h-4" /> Lägg till
              </button>
            </form>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {workers.map(w => (
                <div key={w.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="font-medium text-slate-700">{w.name}</span>
                  <button 
                    onClick={() => onRemoveWorker(w.id)}
                    className="text-slate-400 hover:text-red-500 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPanel;
